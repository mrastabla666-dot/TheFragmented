# GitHub build

This project targets Minecraft 1.21.1 on Fabric and Java 21.

The workflow in `.github/workflows/build.yml` installs Gradle 8.8 and builds the mod on GitHub Actions.

After a successful run:
1. Open the repository's **Actions** tab.
2. Open **Build The Fragmented**.
3. Open the successful workflow run.
4. Download the **The-Fragmented-1.21.1** artifact.
5. The artifact contains the compiled mod JAR from `build/libs/`.

The mod's original Gradle configuration and source code are otherwise left unchanged.
