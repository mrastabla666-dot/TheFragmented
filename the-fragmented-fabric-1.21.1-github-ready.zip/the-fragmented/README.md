# The Fragmented  (Minecraft 1.21.1 · Fabric) — by Dr.Decay

## Build
Requires JDK 21.
- IntelliJ IDEA: File > Open this folder (it imports Gradle automatically), then run the `build` task.
- Or with Gradle 8.8+ installed:  `gradle build`
The mod jar appears in `build/libs/the_fragmented-1.0.0.jar`. Drop it in `.minecraft/mods` with Fabric Loader 0.16+ and Fabric API 0.102.0+1.21.1.

## What's inside
- Tin ore (+deepslate), raw tin, tin ingot/block, tin tools, Rebar Blade, Fragment Blade
- Corrugated Metal Wall: needs support (solid ground, wall below, or adjacent Bamboo Pillar). Hold a Bamboo Stick or Metal String in either hand while placing to "brace" it so it can go anywhere (uses 1).
- Bamboo Pillar (iron-bars style), Bamboo Stick
- Metal String: lays on ground; hot (light, burns/ignites entities, can start fires) when powered redstone is on both opposite sides.
- White Bricks, Aged Bricks (+stairs/slab/wall)
- Cement Block (gravity, hardens to Solid Cement in water, generates underground), Solid Cement (+stairs/slab/wall), Powdered Cement, Bag of Cement (3D block, right-click air to throw)
- Fragmented Concrete + Fragmented Concrete Powder
- Ashwood and Duskwood: log, stripped log, wood, stripped wood, planks, stairs, slab, leaves, sapling, natural trees (taiga / forest)
- Enchantments: Fragmenting, Sturdy Plating, Live Wire
- Constructor Zombie (spawns in the underground "Unfinished Project" structure)
- The Fragmented Guardian (boss, spawns in Strongholds) — spawn eggs for both in the creative tab
