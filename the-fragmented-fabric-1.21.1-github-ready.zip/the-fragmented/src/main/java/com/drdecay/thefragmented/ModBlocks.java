package com.drdecay.thefragmented;

import static com.drdecay.thefragmented.TheFragmented.id;

import com.drdecay.thefragmented.block.BagOfCementBlock;
import com.drdecay.thefragmented.block.CorrugatedMetalWallBlock;
import com.drdecay.thefragmented.block.MetalStringBlock;
import java.util.Optional;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.minecraft.block.*;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.world.gen.feature.ConfiguredFeature;

public class ModBlocks {
	// ---- Ores ----
	public static final Block TIN_ORE = reg("tin_ore", new Block(AbstractBlock.Settings.copy(Blocks.IRON_ORE)), true);
	public static final Block DEEPSLATE_TIN_ORE = reg("deepslate_tin_ore", new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_IRON_ORE)), true);
	public static final Block TIN_BLOCK = reg("tin_block", new Block(AbstractBlock.Settings.copy(Blocks.IRON_BLOCK)), true);

	// ---- Metal / bamboo ----
	public static final Block CORRUGATED_METAL_WALL = reg("corrugated_metal_wall",
		new CorrugatedMetalWallBlock(AbstractBlock.Settings.copy(Blocks.IRON_BLOCK).nonOpaque().strength(3.0f, 6.0f)), true);
	public static final Block BAMBOO_PILLAR = reg("bamboo_pillar",
		new PaneBlock(AbstractBlock.Settings.create().strength(1.0f).sounds(BlockSoundGroup.BAMBOO).nonOpaque()), true);
	public static final Block METAL_STRING = reg("metal_string",
		new MetalStringBlock(AbstractBlock.Settings.create().noCollision().nonOpaque().breakInstantly().ticksRandomly()
			.sounds(BlockSoundGroup.CHAIN).luminance(s -> s.get(MetalStringBlock.HOT) ? 7 : 0)
			.pistonBehavior(net.minecraft.block.piston.PistonBehavior.DESTROY)), true);

	// ---- Cement & concrete ----
	public static final Block SOLID_CEMENT = reg("solid_cement", new Block(AbstractBlock.Settings.copy(Blocks.STONE).strength(1.8f, 6.0f)), true);
	public static final Block CEMENT_BLOCK = reg("cement_block", new ConcretePowderBlock(SOLID_CEMENT, AbstractBlock.Settings.copy(Blocks.GRAVEL)), true);
	public static final Block FRAGMENTED_CONCRETE = reg("fragmented_concrete", new Block(AbstractBlock.Settings.copy(Blocks.WHITE_CONCRETE)), true);
	public static final Block FRAGMENTED_CONCRETE_POWDER = reg("fragmented_concrete_powder",
		new ConcretePowderBlock(FRAGMENTED_CONCRETE, AbstractBlock.Settings.copy(Blocks.WHITE_CONCRETE_POWDER)), true);
	public static final Block BAG_OF_CEMENT = reg("bag_of_cement",
		new BagOfCementBlock(AbstractBlock.Settings.copy(Blocks.WHITE_WOOL).nonOpaque().strength(0.6f)), false);

	// ---- Bricks ----
	public static final Block WHITE_BRICKS = reg("white_bricks", new Block(AbstractBlock.Settings.copy(Blocks.BRICKS)), true);
	public static final Block AGED_BRICKS = reg("aged_bricks", new Block(AbstractBlock.Settings.copy(Blocks.BRICKS)), true);

	static {
		stoneSet("white_brick", WHITE_BRICKS);
		stoneSet("aged_brick", AGED_BRICKS);
		stoneSet("solid_cement", SOLID_CEMENT);
		wood("ashwood", ModWorldGen.ASHWOOD_TREE);
		wood("duskwood", ModWorldGen.DUSKWOOD_TREE);
	}

	private static Block reg(String name, Block block, boolean withItem) {
		Registry.register(Registries.BLOCK, id(name), block);
		if (withItem) Registry.register(Registries.ITEM, id(name), new BlockItem(block, new Item.Settings()));
		return block;
	}

	private static void stoneSet(String stem, Block base) {
		AbstractBlock.Settings s = AbstractBlock.Settings.copy(base);
		reg(stem + "_stairs", new StairsBlock(base.getDefaultState(), s), true);
		reg(stem + "_slab", new SlabBlock(AbstractBlock.Settings.copy(base)), true);
		reg(stem + "_wall", new WallBlock(AbstractBlock.Settings.copy(base).solid()), true);
	}

	private static void wood(String stem, RegistryKey<ConfiguredFeature<?, ?>> treeKey) {
		Block log = reg(stem + "_log", new PillarBlock(AbstractBlock.Settings.copy(Blocks.OAK_LOG)), true);
		Block strippedLog = reg("stripped_" + stem + "_log", new PillarBlock(AbstractBlock.Settings.copy(Blocks.OAK_LOG)), true);
		Block wood = reg(stem + "_wood", new PillarBlock(AbstractBlock.Settings.copy(Blocks.OAK_WOOD)), true);
		Block strippedWood = reg("stripped_" + stem + "_wood", new PillarBlock(AbstractBlock.Settings.copy(Blocks.OAK_WOOD)), true);
		Block planks = reg(stem + "_planks", new Block(AbstractBlock.Settings.copy(Blocks.OAK_PLANKS)), true);
		Block stairs = reg(stem + "_stairs", new StairsBlock(planks.getDefaultState(), AbstractBlock.Settings.copy(Blocks.OAK_PLANKS)), true);
		Block slab = reg(stem + "_slab", new SlabBlock(AbstractBlock.Settings.copy(Blocks.OAK_SLAB)), true);
		Block leaves = reg(stem + "_leaves", new LeavesBlock(AbstractBlock.Settings.copy(Blocks.OAK_LEAVES)), true);
		SaplingGenerator gen = new SaplingGenerator(stem, Optional.empty(), Optional.of(treeKey), Optional.empty());
		reg(stem + "_sapling", new SaplingBlock(gen, AbstractBlock.Settings.copy(Blocks.OAK_SAPLING)), true);

		StrippableBlockRegistry.register(log, strippedLog);
		StrippableBlockRegistry.register(wood, strippedWood);
		FlammableBlockRegistry reg = FlammableBlockRegistry.getDefaultInstance();
		for (Block b : new Block[] { log, strippedLog, wood, strippedWood }) reg.add(b, 5, 5);
		for (Block b : new Block[] { planks, stairs, slab }) reg.add(b, 5, 20);
		reg.add(leaves, 30, 60);
	}

	public static void init() {}
}
