package com.drdecay.thefragmented.client;

import static com.drdecay.thefragmented.TheFragmented.MOD_ID;

import com.drdecay.thefragmented.ModBlocks;
import com.drdecay.thefragmented.ModEntities;
import com.drdecay.thefragmented.entity.FragmentedGuardianEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.block.Block;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;
import net.minecraft.client.render.entity.ZombieEntityRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

public class TheFragmentedClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		for (Block b : Registries.BLOCK) {
			Identifier id = Registries.BLOCK.getId(b);
			if (!id.getNamespace().equals(MOD_ID)) continue;
			String p = id.getPath();
			if (p.endsWith("_leaves") || p.endsWith("_sapling") || p.equals("bamboo_pillar") || p.equals("metal_string")) {
				BlockRenderLayerMap.INSTANCE.putBlock(b, RenderLayer.getCutoutMipped());
			}
		}
		EntityRendererRegistry.register(ModEntities.CONSTRUCTOR_ZOMBIE, ConstructorZombieRenderer::new);
		EntityRendererRegistry.register(ModEntities.FRAGMENTED_GUARDIAN, GuardianRenderer::new);
		EntityRendererRegistry.register(ModEntities.CEMENT_BAG, FlyingItemEntityRenderer::new);
	}

	static class ConstructorZombieRenderer extends ZombieEntityRenderer {
		private static final Identifier TEX = Identifier.of(MOD_ID, "textures/entity/constructor_zombie.png");

		ConstructorZombieRenderer(EntityRendererFactory.Context ctx) {
			super(ctx);
		}

		@Override
		public Identifier getTexture(ZombieEntity entity) {
			return TEX;
		}
	}

	static class GuardianRenderer extends BipedEntityRenderer<FragmentedGuardianEntity, BipedEntityModel<FragmentedGuardianEntity>> {
		private static final Identifier TEX = Identifier.of(MOD_ID, "textures/entity/fragmented_guardian.png");

		GuardianRenderer(EntityRendererFactory.Context ctx) {
			super(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE)), 0.9f);
		}

		@Override
		public Identifier getTexture(FragmentedGuardianEntity entity) {
			return TEX;
		}

		@Override
		protected void scale(FragmentedGuardianEntity entity, MatrixStack matrices, float amount) {
			matrices.scale(1.8f, 1.8f, 1.8f);
		}
	}
}
