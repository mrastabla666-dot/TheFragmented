package com.drdecay.thefragmented.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

/** Thin wire laid on the ground. Becomes hot when powered redstone sits on both sides of it. */
public class MetalStringBlock extends Block {
	public static final MapCodec<MetalStringBlock> CODEC = createCodec(MetalStringBlock::new);
	public static final BooleanProperty HOT = BooleanProperty.of("hot");
	private static final VoxelShape SHAPE = Block.createCuboidShape(0, 0, 0, 16, 1, 16);

	public MetalStringBlock(Settings settings) {
		super(settings);
		setDefaultState(getStateManager().getDefaultState().with(HOT, false));
	}

	@Override
	protected MapCodec<? extends Block> getCodec() {
		return CODEC;
	}

	@Override
	protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
		builder.add(HOT);
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return SHAPE;
	}

	@Override
	protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
		return Block.sideCoversSmallSquare(world, pos.down(), Direction.UP);
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		return getDefaultState().with(HOT, isHot(ctx.getWorld(), ctx.getBlockPos()));
	}

	@Override
	protected BlockState getStateForNeighborUpdate(BlockState state, Direction direction, BlockState neighborState, WorldAccess world, BlockPos pos, BlockPos neighborPos) {
		return !state.canPlaceAt(world, pos) ? Blocks.AIR.getDefaultState() : state;
	}

	@Override
	protected void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock, BlockPos sourcePos, boolean notify) {
		if (world.isClient) return;
		boolean hot = isHot(world, pos);
		if (hot != state.get(HOT)) world.setBlockState(pos, state.with(HOT, hot), Block.NOTIFY_ALL);
	}

	@Override
	protected void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
		if (world.isClient || !state.get(HOT)) return;
		entity.damage(world.getDamageSources().inFire(), 2.0f);
		entity.setOnFireFor(4);
	}

	@Override
	protected void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
		if (!state.get(HOT) || random.nextInt(3) != 0) return;
		Direction dir = Direction.values()[random.nextInt(Direction.values().length)];
		if (dir == Direction.DOWN) return;
		BlockPos target = pos.offset(dir);
		if (AbstractFireBlock.canPlaceAt(world, target, dir)) {
			world.setBlockState(target, AbstractFireBlock.getState(world, target));
		}
	}

	private static boolean isHot(BlockView world, BlockPos pos) {
		return (powered(world.getBlockState(pos.north())) && powered(world.getBlockState(pos.south())))
			|| (powered(world.getBlockState(pos.east())) && powered(world.getBlockState(pos.west())));
	}

	private static boolean powered(BlockState s) {
		if (s.isOf(Blocks.REDSTONE_WIRE)) return s.get(RedstoneWireBlock.POWER) > 0;
		if (s.isOf(Blocks.REDSTONE_BLOCK)) return true;
		if (s.isOf(Blocks.REDSTONE_TORCH)) return s.get(RedstoneTorchBlock.LIT);
		if (s.isOf(Blocks.REDSTONE_WALL_TORCH)) return s.get(RedstoneTorchBlock.LIT);
		return false;
	}
}
