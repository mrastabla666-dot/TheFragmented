package com.drdecay.thefragmented.block;

import com.drdecay.thefragmented.ModBlocks;
import com.drdecay.thefragmented.ModItems;
import com.mojang.serialization.MapCodec;
import java.util.List;
import net.minecraft.block.*;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import net.minecraft.world.World;

/**
 * Thin metal panel. It needs support (solid ground, a wall below it, or an adjacent Bamboo Pillar)
 * unless it is "braced": hold a Bamboo Stick or Metal String in your other hand while placing to
 * brace it so it can be placed anywhere (one brace item is used up).
 */
public class CorrugatedMetalWallBlock extends HorizontalFacingBlock {
	public static final MapCodec<CorrugatedMetalWallBlock> CODEC = createCodec(CorrugatedMetalWallBlock::new);
	public static final BooleanProperty BRACED = BooleanProperty.of("braced");
	private static final VoxelShape NS = Block.createCuboidShape(0, 0, 6.5, 16, 16, 9.5);
	private static final VoxelShape EW = Block.createCuboidShape(6.5, 0, 0, 9.5, 16, 16);

	public CorrugatedMetalWallBlock(Settings settings) {
		super(settings);
		setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH).with(BRACED, false));
	}

	@Override
	protected MapCodec<? extends HorizontalFacingBlock> getCodec() {
		return CODEC;
	}

	@Override
	protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
		builder.add(FACING, BRACED);
	}

	@Override
	protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return state.get(FACING).getAxis() == Direction.Axis.X ? EW : NS;
	}

	@Override
	public BlockState getPlacementState(ItemPlacementContext ctx) {
		return getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing()).with(BRACED, findBrace(ctx.getPlayer()) != null);
	}

	@Override
	protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
		return state.get(BRACED) || supported(world, pos);
	}

	private boolean supported(WorldView world, BlockPos pos) {
		BlockPos below = pos.down();
		BlockState b = world.getBlockState(below);
		if (b.isSideSolidFullSquare(world, below, Direction.UP) || b.isOf(this)) return true;
		for (Direction d : Direction.Type.HORIZONTAL) {
			if (world.getBlockState(pos.offset(d)).isOf(ModBlocks.BAMBOO_PILLAR)) return true;
		}
		return false;
	}

	@Override
	protected BlockState getStateForNeighborUpdate(BlockState state, Direction direction, BlockState neighborState, WorldAccess world, BlockPos pos, BlockPos neighborPos) {
		return !state.canPlaceAt(world, pos) ? Blocks.AIR.getDefaultState() : state;
	}

	@Override
	public void onPlaced(World world, BlockPos pos, BlockState state, LivingEntity placer, ItemStack itemStack) {
		if (state.get(BRACED) && placer instanceof PlayerEntity p && !p.isCreative()) {
			ItemStack brace = findBrace(p);
			if (brace != null) brace.decrement(1);
		}
	}

	private static ItemStack findBrace(PlayerEntity player) {
		if (player == null) return null;
		for (ItemStack s : List.of(player.getOffHandStack(), player.getMainHandStack())) {
			if (s.isOf(ModItems.BAMBOO_STICK) || s.isOf(ModBlocks.METAL_STRING.asItem())) return s;
		}
		return null;
	}
}
