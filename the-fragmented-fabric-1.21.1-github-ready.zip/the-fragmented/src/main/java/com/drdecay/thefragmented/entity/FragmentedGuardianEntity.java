package com.drdecay.thefragmented.entity;

import com.drdecay.thefragmented.ModEntities;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/** Stronghold boss. Periodically releases a shockwave and calls Constructor Zombies. */
public class FragmentedGuardianEntity extends HostileEntity {
	private final ServerBossBar bossBar = new ServerBossBar(getDisplayName(), BossBar.Color.PURPLE, BossBar.Style.NOTCHED_10);
	private int burstCooldown = 100;

	public FragmentedGuardianEntity(EntityType<? extends HostileEntity> type, World world) {
		super(type, world);
		this.experiencePoints = 120;
	}

	public static DefaultAttributeContainer.Builder createAttributes() {
		return HostileEntity.createHostileAttributes()
			.add(EntityAttributes.GENERIC_MAX_HEALTH, 300.0)
			.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.28)
			.add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 10.0)
			.add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.8)
			.add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0)
			.add(EntityAttributes.GENERIC_ARMOR, 8.0);
	}

	@Override
	protected void initGoals() {
		goalSelector.add(0, new SwimGoal(this));
		goalSelector.add(2, new MeleeAttackGoal(this, 1.0, false));
		goalSelector.add(5, new WanderAroundFarGoal(this, 0.6));
		goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 10.0f));
		goalSelector.add(7, new LookAroundGoal(this));
		targetSelector.add(1, new RevengeGoal(this));
		targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
	}

	@Override
	protected void mobTick() {
		super.mobTick();
		bossBar.setPercent(getHealth() / getMaxHealth());
		if (getTarget() != null && --burstCooldown <= 0) {
			burstCooldown = 160;
			shatterBurst();
		}
		if (age % 40 == 0) heal(1.0f);
	}

	private void shatterBurst() {
		if (!(getWorld() instanceof ServerWorld sw)) return;
		sw.spawnParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.5, getZ(), 12, 3.0, 0.3, 3.0, 0.0);
		sw.playSound(null, getBlockPos(), SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.HOSTILE, 2.0f, 0.5f);
		for (PlayerEntity p : sw.getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(10.0),
			pl -> pl.isAlive() && !pl.isCreative() && !pl.isSpectator())) {
			p.damage(getDamageSources().mobAttack(this), 6.0f);
			p.takeKnockback(1.2, getX() - p.getX(), getZ() - p.getZ());
			p.velocityModified = true;
		}
		int nearby = sw.getEntitiesByClass(ConstructorZombieEntity.class, getBoundingBox().expand(16.0), e -> true).size();
		if (nearby < 4) {
			for (int i = 0; i < 2; i++) {
				ConstructorZombieEntity z = ModEntities.CONSTRUCTOR_ZOMBIE.create(sw);
				if (z == null) continue;
				z.refreshPositionAndAngles(getX() + (random.nextDouble() - 0.5) * 5, getY(), getZ() + (random.nextDouble() - 0.5) * 5, random.nextFloat() * 360f, 0f);
				z.initialize(sw, sw.getLocalDifficulty(z.getBlockPos()), SpawnReason.MOB_SUMMONED, null);
				sw.spawnEntity(z);
			}
		}
	}

	/** Only one guardian per area, and only sometimes, so strongholds don't fill with bosses. */
	@Override
	public boolean canSpawn(WorldAccess world, SpawnReason spawnReason) {
		if (spawnReason == SpawnReason.NATURAL && world instanceof World w) {
			if (random.nextInt(4) != 0) return false;
			if (!w.getEntitiesByClass(FragmentedGuardianEntity.class, getBoundingBox().expand(160.0), e -> true).isEmpty()) return false;
		}
		return super.canSpawn(world, spawnReason);
	}

	@Override
	public void checkDespawn() {}

	@Override
	public void setCustomName(Text name) {
		super.setCustomName(name);
		bossBar.setName(getDisplayName());
	}

	@Override
	public void onStartedTrackingBy(ServerPlayerEntity player) {
		super.onStartedTrackingBy(player);
		bossBar.addPlayer(player);
	}

	@Override
	public void onStoppedTrackingBy(ServerPlayerEntity player) {
		super.onStoppedTrackingBy(player);
		bossBar.removePlayer(player);
	}
}
