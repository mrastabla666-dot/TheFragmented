package com.drdecay.thefragmented;

import static com.drdecay.thefragmented.TheFragmented.id;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.PlacedFeature;

public class ModWorldGen {
	public static final RegistryKey<ConfiguredFeature<?, ?>> ASHWOOD_TREE = RegistryKey.of(RegistryKeys.CONFIGURED_FEATURE, id("ashwood_tree"));
	public static final RegistryKey<ConfiguredFeature<?, ?>> DUSKWOOD_TREE = RegistryKey.of(RegistryKeys.CONFIGURED_FEATURE, id("duskwood_tree"));

	private static RegistryKey<PlacedFeature> placed(String name) {
		return RegistryKey.of(RegistryKeys.PLACED_FEATURE, id(name));
	}

	public static void init() {
		BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), GenerationStep.Feature.UNDERGROUND_ORES, placed("ore_tin"));
		BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), GenerationStep.Feature.UNDERGROUND_ORES, placed("ore_cement"));
		BiomeModifications.addFeature(BiomeSelectors.tag(BiomeTags.IS_TAIGA), GenerationStep.Feature.VEGETAL_DECORATION, placed("ashwood_tree_placed"));
		BiomeModifications.addFeature(BiomeSelectors.tag(BiomeTags.IS_FOREST), GenerationStep.Feature.VEGETAL_DECORATION, placed("duskwood_tree_placed"));
	}
}
