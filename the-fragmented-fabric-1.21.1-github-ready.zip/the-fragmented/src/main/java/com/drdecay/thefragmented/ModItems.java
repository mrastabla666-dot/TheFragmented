package com.drdecay.thefragmented;

import static com.drdecay.thefragmented.TheFragmented.MOD_ID;
import static com.drdecay.thefragmented.TheFragmented.id;

import com.drdecay.thefragmented.item.BagOfCementItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

public class ModItems {
	public static final Item RAW_TIN = reg("raw_tin", new Item(new Item.Settings()));
	public static final Item TIN_INGOT = reg("tin_ingot", new Item(new Item.Settings()));
	public static final Item BAMBOO_STICK = reg("bamboo_stick", new Item(new Item.Settings()));
	public static final Item POWDERED_CEMENT = reg("powdered_cement", new Item(new Item.Settings()));
	public static final Item FRAGMENT_SHARD = reg("fragment_shard", new Item(new Item.Settings()));
	public static final Item BAG_OF_CEMENT = reg("bag_of_cement", new BagOfCementItem(ModBlocks.BAG_OF_CEMENT, new Item.Settings().maxCount(16)));

	public static final Item TIN_SWORD = reg("tin_sword", new SwordItem(ModToolMaterials.TIN, new Item.Settings().attributeModifiers(SwordItem.createAttributeModifiers(ModToolMaterials.TIN, 3, -2.4f))));
	public static final Item TIN_PICKAXE = reg("tin_pickaxe", new PickaxeItem(ModToolMaterials.TIN, new Item.Settings().attributeModifiers(PickaxeItem.createAttributeModifiers(ModToolMaterials.TIN, 1.0f, -2.8f))));
	public static final Item TIN_AXE = reg("tin_axe", new AxeItem(ModToolMaterials.TIN, new Item.Settings().attributeModifiers(AxeItem.createAttributeModifiers(ModToolMaterials.TIN, 6.0f, -3.1f))));
	public static final Item TIN_SHOVEL = reg("tin_shovel", new ShovelItem(ModToolMaterials.TIN, new Item.Settings().attributeModifiers(ShovelItem.createAttributeModifiers(ModToolMaterials.TIN, 1.5f, -3.0f))));
	public static final Item TIN_HOE = reg("tin_hoe", new HoeItem(ModToolMaterials.TIN, new Item.Settings().attributeModifiers(HoeItem.createAttributeModifiers(ModToolMaterials.TIN, -2.0f, -1.0f))));
	public static final Item REBAR_BLADE = reg("rebar_blade", new SwordItem(ModToolMaterials.REBAR, new Item.Settings().attributeModifiers(SwordItem.createAttributeModifiers(ModToolMaterials.REBAR, 4, -2.6f))));
	public static final Item FRAGMENT_BLADE = reg("fragment_blade", new SwordItem(ModToolMaterials.FRAGMENT, new Item.Settings().attributeModifiers(SwordItem.createAttributeModifiers(ModToolMaterials.FRAGMENT, 4, -2.2f))));

	public static final Item CONSTRUCTOR_ZOMBIE_SPAWN_EGG = reg("constructor_zombie_spawn_egg", new SpawnEggItem(ModEntities.CONSTRUCTOR_ZOMBIE, 0xE0A030, 0x5A6470, new Item.Settings()));
	public static final Item FRAGMENTED_GUARDIAN_SPAWN_EGG = reg("fragmented_guardian_spawn_egg", new SpawnEggItem(ModEntities.FRAGMENTED_GUARDIAN, 0x6A4A9A, 0x1E1830, new Item.Settings()));

	public static final ItemGroup GROUP = Registry.register(Registries.ITEM_GROUP, id("main"),
		FabricItemGroup.builder()
			.icon(() -> new ItemStack(TIN_INGOT))
			.displayName(Text.translatable("itemGroup.the_fragmented.main"))
			.entries((ctx, entries) -> {
				for (Item item : Registries.ITEM) {
					if (Registries.ITEM.getId(item).getNamespace().equals(MOD_ID)) entries.add(item);
				}
			}).build());

	private static Item reg(String name, Item item) {
		return Registry.register(Registries.ITEM, id(name), item);
	}

	public static void init() {}
}
