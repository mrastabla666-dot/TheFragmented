package com.drdecay.thefragmented;

import java.util.function.Supplier;
import net.minecraft.block.Block;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;

public enum ModToolMaterials implements ToolMaterial {
	TIN(BlockTags.INCORRECT_FOR_IRON_TOOL, 190, 5.5f, 1.5f, 14, () -> Ingredient.ofItems(ModItems.TIN_INGOT)),
	REBAR(BlockTags.INCORRECT_FOR_IRON_TOOL, 320, 6.0f, 2.5f, 8, () -> Ingredient.ofItems(net.minecraft.item.Items.IRON_INGOT)),
	FRAGMENT(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 1400, 8.0f, 3.5f, 18, () -> Ingredient.ofItems(ModItems.FRAGMENT_SHARD));

	private final TagKey<Block> inverseTag;
	private final int durability;
	private final float speed;
	private final float damage;
	private final int enchantability;
	private final Supplier<Ingredient> repair;

	ModToolMaterials(TagKey<Block> inverseTag, int durability, float speed, float damage, int enchantability, Supplier<Ingredient> repair) {
		this.inverseTag = inverseTag;
		this.durability = durability;
		this.speed = speed;
		this.damage = damage;
		this.enchantability = enchantability;
		this.repair = repair;
	}

	@Override public int getDurability() { return durability; }
	@Override public float getMiningSpeedMultiplier() { return speed; }
	@Override public float getAttackDamage() { return damage; }
	@Override public TagKey<Block> getInverseTag() { return inverseTag; }
	@Override public int getEnchantability() { return enchantability; }
	@Override public Ingredient getRepairIngredient() { return repair.get(); }
}
