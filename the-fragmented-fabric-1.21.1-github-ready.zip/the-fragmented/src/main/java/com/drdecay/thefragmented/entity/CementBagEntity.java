package com.drdecay.thefragmented.entity;

import com.drdecay.thefragmented.ModBlocks;
import com.drdecay.thefragmented.ModEntities;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;
import org.joml.Vector3f;

public class CementBagEntity extends ThrownItemEntity {
	public CementBagEntity(EntityType<? extends CementBagEntity> type, World world) {
		super(type, world);
	}

	public CementBagEntity(World world, LivingEntity owner) {
		super(ModEntities.CEMENT_BAG, owner, world);
	}

	@Override
	protected Item getDefaultItem() {
		return ModBlocks.BAG_OF_CEMENT.asItem();
	}

	@Override
	protected void onEntityHit(EntityHitResult hit) {
		super.onEntityHit(hit);
		hit.getEntity().damage(getDamageSources().thrown(this, getOwner()), 5.0f);
		if (hit.getEntity() instanceof LivingEntity living) {
			living.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 1));
		}
	}

	@Override
	protected void onCollision(HitResult hit) {
		super.onCollision(hit);
		if (getWorld() instanceof ServerWorld sw) {
			sw.spawnParticles(new DustParticleEffect(new Vector3f(0.78f, 0.78f, 0.78f), 3.0f),
				getX(), getY() + 0.2, getZ(), 90, 1.0, 0.7, 1.0, 0.02);
			sw.spawnParticles(ParticleTypes.CLOUD, getX(), getY() + 0.2, getZ(), 20, 0.8, 0.5, 0.8, 0.02);
			sw.playSound(null, getBlockPos(), SoundEvents.BLOCK_SAND_BREAK, SoundCategory.NEUTRAL, 1.2f, 0.7f);
			discard();
		}
	}
}
