package com.drdecay.thefragmented;

import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;

public class TheFragmented implements ModInitializer {
	public static final String MOD_ID = "the_fragmented";

	public static Identifier id(String path) {
		return Identifier.of(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModBlocks.init();
		ModEntities.init();
		ModItems.init();
		ModWorldGen.init();
	}
}
