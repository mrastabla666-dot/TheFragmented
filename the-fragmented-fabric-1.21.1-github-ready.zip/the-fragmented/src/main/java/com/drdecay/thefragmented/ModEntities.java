package com.drdecay.thefragmented;

import static com.drdecay.thefragmented.TheFragmented.id;

import com.drdecay.thefragmented.entity.CementBagEntity;
import com.drdecay.thefragmented.entity.ConstructorZombieEntity;
import com.drdecay.thefragmented.entity.FragmentedGuardianEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModEntities {
	public static final EntityType<ConstructorZombieEntity> CONSTRUCTOR_ZOMBIE = reg("constructor_zombie",
		EntityType.Builder.create(ConstructorZombieEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.95f).maxTrackingRange(8));
	public static final EntityType<FragmentedGuardianEntity> FRAGMENTED_GUARDIAN = reg("fragmented_guardian",
		EntityType.Builder.create(FragmentedGuardianEntity::new, SpawnGroup.MONSTER).dimensions(1.1f, 3.5f).maxTrackingRange(10));
	public static final EntityType<CementBagEntity> CEMENT_BAG = reg("cement_bag",
		EntityType.Builder.<CementBagEntity>create(CementBagEntity::new, SpawnGroup.MISC).dimensions(0.35f, 0.35f).maxTrackingRange(4).trackingTickInterval(10));

	private static <T extends Entity> EntityType<T> reg(String name, EntityType.Builder<T> builder) {
		return Registry.register(Registries.ENTITY_TYPE, id(name), builder.build(name));
	}

	public static void init() {
		FabricDefaultAttributeRegistry.register(CONSTRUCTOR_ZOMBIE, ConstructorZombieEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(FRAGMENTED_GUARDIAN, FragmentedGuardianEntity.createAttributes());
	}
}
