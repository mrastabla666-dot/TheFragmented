package net.drdecay.thefragmented.client;

import net.drdecay.thefragmented.TheFragmented;
import net.drdecay.thefragmented.entity.ConstructorZombieEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.ZombieBaseEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.ZombieEntityModel;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.Identifier;

public class ConstructorZombieRenderer extends ZombieBaseEntityRenderer<ConstructorZombieEntity, ZombieEntityModel<ConstructorZombieEntity>> {
	private static final Identifier TEX = TheFragmented.id("textures/entity/constructor_zombie.png");

	public ConstructorZombieRenderer(EntityRendererFactory.Context ctx) {
		super(ctx,
				new ZombieEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE)),
				new ZombieEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE_INNER_ARMOR)),
				new ZombieEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE_OUTER_ARMOR)));
	}

	@Override
	public Identifier getTexture(ZombieEntity entity) { return TEX; }
}
