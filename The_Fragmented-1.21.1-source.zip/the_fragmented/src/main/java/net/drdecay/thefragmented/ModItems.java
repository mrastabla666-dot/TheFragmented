package net.drdecay.thefragmented;

import static net.drdecay.thefragmented.TheFragmented.id;

import java.util.ArrayList;
import java.util.List;
import net.drdecay.thefragmented.item.TinMaterial;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class ModItems {
	public static final List<ItemConvertible> ENTRIES = new ArrayList<>();

	private static <T extends Item> T reg(String n, T i) {
		Registry.register(Registries.ITEM, id(n), i);
		ENTRIES.add(i);
		return i;
	}

	private static Item.Settings s() { return new Item.Settings(); }

	public static final Item RAW_TIN = reg("raw_tin", new Item(s()));
	public static final Item TIN_INGOT = reg("tin_ingot", new Item(s()));
	public static final Item POWDERED_CEMENT = reg("powdered_cement", new Item(s()));
	public static final Item BAMBOO_STICK = reg("bamboo_stick", new Item(s()));

	private static final TinMaterial M = TinMaterial.INSTANCE;
	public static final Item TIN_SWORD = reg("tin_sword", new SwordItem(M, s().attributeModifiers(SwordItem.createAttributeModifiers(M, 3, -2.4f))));
	public static final Item TIN_PICKAXE = reg("tin_pickaxe", new PickaxeItem(M, s().attributeModifiers(PickaxeItem.createAttributeModifiers(M, 1.0f, -2.8f))));
	public static final Item TIN_AXE = reg("tin_axe", new AxeItem(M, s().attributeModifiers(AxeItem.createAttributeModifiers(M, 6.0f, -3.1f))));
	public static final Item TIN_SHOVEL = reg("tin_shovel", new ShovelItem(M, s().attributeModifiers(ShovelItem.createAttributeModifiers(M, 1.5f, -3.0f))));
	public static final Item TIN_HOE = reg("tin_hoe", new HoeItem(M, s().attributeModifiers(HoeItem.createAttributeModifiers(M, -1.0f, -2.0f))));
	public static final Item TIN_WARHAMMER = reg("tin_warhammer", new SwordItem(M, s().attributeModifiers(SwordItem.createAttributeModifiers(M, 6, -3.2f))));

	public static final Item FRAGMENTED_KING_SPAWN_EGG = reg("fragmented_king_spawn_egg", new SpawnEggItem(ModEntities.FRAGMENTED_KING, 0x2b1b3d, 0xb15bff, s()));
	public static final Item CONSTRUCTOR_ZOMBIE_SPAWN_EGG = reg("constructor_zombie_spawn_egg", new SpawnEggItem(ModEntities.CONSTRUCTOR_ZOMBIE, 0x6e965a, 0xf0c814, s()));

	public static void init() {}
}
