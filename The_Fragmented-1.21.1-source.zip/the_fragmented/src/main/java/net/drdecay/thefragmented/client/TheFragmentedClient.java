package net.drdecay.thefragmented.client;

import net.drdecay.thefragmented.ModBlocks;
import net.drdecay.thefragmented.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;

public class TheFragmentedClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		for (ModBlocks.Wood w : new ModBlocks.Wood[]{ModBlocks.ASHEN, ModBlocks.DUSK}) {
			BlockRenderLayerMap.INSTANCE.putBlock(w.leaves(), RenderLayer.getCutoutMipped());
			BlockRenderLayerMap.INSTANCE.putBlock(w.sapling(), RenderLayer.getCutout());
		}
		BlockRenderLayerMap.INSTANCE.putBlocks(RenderLayer.getCutout(), ModBlocks.CORRUGATED_METAL_WALL, ModBlocks.BAMBOO_PILLAR, ModBlocks.METAL_STRING);
		EntityRendererRegistry.register(ModEntities.CEMENT_BAG, FlyingItemEntityRenderer::new);
		EntityRendererRegistry.register(ModEntities.CONSTRUCTOR_ZOMBIE, ConstructorZombieRenderer::new);
		EntityRendererRegistry.register(ModEntities.FRAGMENTED_KING, FragmentedKingRenderer::new);
	}
}
