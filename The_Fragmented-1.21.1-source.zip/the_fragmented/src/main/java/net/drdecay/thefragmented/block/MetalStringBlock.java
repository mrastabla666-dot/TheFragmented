package net.drdecay.thefragmented.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

/** Thin wire laid on the ground. Between two powered redstone sources it turns hot: burns mobs and starts fires. */
public class MetalStringBlock extends Block {
	public static final MapCodec<MetalStringBlock> CODEC = createCodec(MetalStringBlock::new);
	public static final BooleanProperty HOT = BooleanProperty.of("hot");
	private static final VoxelShape SHAPE = Block.createCuboidShape(0, 0, 0, 16, 1, 16);

	public MetalStringBlock(Settings settings) {
		super(settings);
		setDefaultState(getStateManager().getDefaultState().with(HOT, false));
	}

	@Override
	protected MapCodec<? extends Block> getCodec() { return CODEC; }

	@Override
	protected void appendProperties(StateManager.Builder<Block, BlockState> b) { b.add(HOT); }

	@Override
	public VoxelShape getOutlineShape(BlockState s, BlockView w, BlockPos p, ShapeContext c) { return SHAPE; }

	@Override
	public boolean canPlaceAt(BlockState s, WorldView w, BlockPos p) {
		BlockPos d = p.down();
		return w.getBlockState(d).isSideSolidFullSquare(w, d, Direction.UP);
	}

	@Override
	public BlockState getStateForNeighborUpdate(BlockState s, Direction dir, BlockState n, WorldAccess w, BlockPos p, BlockPos np) {
		return canPlaceAt(s, w, p) ? s : Blocks.AIR.getDefaultState();
	}

	@Override
	public void onBlockAdded(BlockState s, World w, BlockPos p, BlockState old, boolean moved) {
		if (!w.isClient) w.scheduleBlockTick(p, this, 2);
	}

	@Override
	public void neighborUpdate(BlockState s, World w, BlockPos p, Block src, BlockPos sp, boolean notify) {
		if (!w.isClient) w.scheduleBlockTick(p, this, 2);
	}

	private static boolean powered(World w, BlockPos p, Direction towardsString) {
		BlockState s = w.getBlockState(p);
		if (s.isOf(Blocks.REDSTONE_WIRE)) return s.get(RedstoneWireBlock.POWER) > 0;
		return s.emitsRedstonePower() && s.getWeakRedstonePower(w, p, towardsString.getOpposite()) > 0;
	}

	@Override
	public void scheduledTick(BlockState s, ServerWorld w, BlockPos p, Random r) {
		boolean hot = (powered(w, p.west(), Direction.WEST) && powered(w, p.east(), Direction.EAST))
				|| (powered(w, p.north(), Direction.NORTH) && powered(w, p.south(), Direction.SOUTH));
		if (hot != s.get(HOT)) w.setBlockState(p, s.with(HOT, hot), Block.NOTIFY_ALL);
		if (hot) {
			if (r.nextInt(6) == 0) {
				Direction d = Direction.values()[1 + r.nextInt(5)]; // any side except down
				BlockPos t = p.offset(d);
				if (w.getBlockState(t).isAir() && Blocks.FIRE.getDefaultState().canPlaceAt(w, t))
					w.setBlockState(t, AbstractFireBlock.getState(w, t));
			}
			w.scheduleBlockTick(p, this, 10);
		}
	}

	@Override
	public void onEntityCollision(BlockState s, World w, BlockPos p, Entity e) {
		if (!w.isClient && s.get(HOT) && e instanceof LivingEntity) {
			e.damage(w.getDamageSources().inFire(), 2.0f);
			e.setOnFireFor(4);
		}
	}
}
