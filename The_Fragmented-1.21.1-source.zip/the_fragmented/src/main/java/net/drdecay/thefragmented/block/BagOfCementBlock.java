package net.drdecay.thefragmented.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

/** Slab-height bag, 2 blocks wide by 1 long (hit-box rotates with facing). */
public class BagOfCementBlock extends HorizontalFacingBlock {
	public static final MapCodec<BagOfCementBlock> CODEC = createCodec(BagOfCementBlock::new);
	private static final VoxelShape NS = Block.createCuboidShape(0, 0, 4, 16, 5, 12);
	private static final VoxelShape EW = Block.createCuboidShape(4, 0, 0, 12, 5, 16);

	public BagOfCementBlock(Settings settings) {
		super(settings);
		setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH));
	}

	@Override
	protected MapCodec<? extends HorizontalFacingBlock> getCodec() { return CODEC; }

	@Override
	protected void appendProperties(StateManager.Builder<Block, BlockState> b) { b.add(FACING); }

	@Override
	public BlockState getPlacementState(ItemPlacementContext c) {
		return getDefaultState().with(FACING, c.getHorizontalPlayerFacing());
	}

	@Override
	public VoxelShape getOutlineShape(BlockState s, BlockView w, BlockPos p, ShapeContext c) {
		return s.get(FACING).getAxis() == Direction.Axis.Z ? NS : EW;
	}

	@Override
	public boolean canPlaceAt(BlockState s, WorldView w, BlockPos p) {
		BlockPos d = p.down();
		return w.getBlockState(d).isSideSolidFullSquare(w, d, Direction.UP);
	}

	@Override
	public BlockState getStateForNeighborUpdate(BlockState s, Direction dir, BlockState n, WorldAccess w, BlockPos p, BlockPos np) {
		return canPlaceAt(s, w, p) ? s : Blocks.AIR.getDefaultState();
	}
}
