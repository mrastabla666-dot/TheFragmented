package net.drdecay.thefragmented.entity;

import net.drdecay.thefragmented.ModItems;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

public class ConstructorZombieEntity extends ZombieEntity {
	public ConstructorZombieEntity(EntityType<? extends ZombieEntity> type, World world) { super(type, world); }

	@Override
	protected void initEquipment(Random random, LocalDifficulty difficulty) {
		equipStack(EquipmentSlot.MAINHAND, new ItemStack(random.nextBoolean() ? ModItems.TIN_PICKAXE : ModItems.TIN_WARHAMMER));
		equipStack(EquipmentSlot.HEAD, new ItemStack(Items.GOLDEN_HELMET)); // hard hat
	}
}
