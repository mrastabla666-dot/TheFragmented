package net.drdecay.thefragmented.entity;

import net.drdecay.thefragmented.ModBlocks;
import net.drdecay.thefragmented.ModEntities;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;
import org.joml.Vector3f;

public class CementBagEntity extends ThrownItemEntity {
	public CementBagEntity(EntityType<? extends CementBagEntity> type, World world) { super(type, world); }

	public CementBagEntity(World world, LivingEntity owner) { super(ModEntities.CEMENT_BAG, owner, world); }

	@Override
	protected Item getDefaultItem() { return ModBlocks.BAG_OF_CEMENT.asItem(); }

	@Override
	protected void onEntityHit(EntityHitResult r) {
		super.onEntityHit(r);
		Entity e = r.getEntity();
		e.damage(getDamageSources().thrown(this, getOwner()), 5.0f);
	}

	@Override
	protected void onCollision(HitResult r) {
		super.onCollision(r);
		if (getWorld() instanceof ServerWorld sw) {
			sw.spawnParticles(new DustParticleEffect(new Vector3f(0.75f, 0.75f, 0.75f), 3.0f), getX(), getY(), getZ(), 80, 0.7, 0.5, 0.7, 0.02);
			sw.spawnParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, getX(), getY(), getZ(), 12, 0.5, 0.3, 0.5, 0.01);
			sw.playSound(null, getX(), getY(), getZ(), SoundEvents.BLOCK_WOOL_BREAK, SoundCategory.BLOCKS, 1.0f, 0.7f);
			discard();
		}
	}
}
