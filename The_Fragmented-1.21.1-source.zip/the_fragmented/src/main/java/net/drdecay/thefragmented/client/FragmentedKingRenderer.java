package net.drdecay.thefragmented.client;

import net.drdecay.thefragmented.TheFragmented;
import net.drdecay.thefragmented.entity.FragmentedKingEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.SkeletonEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class FragmentedKingRenderer extends BipedEntityRenderer<FragmentedKingEntity, SkeletonEntityModel<FragmentedKingEntity>> {
	private static final Identifier TEX = TheFragmented.id("textures/entity/fragmented_king.png");

	public FragmentedKingRenderer(EntityRendererFactory.Context ctx) {
		super(ctx, new SkeletonEntityModel<>(ctx.getPart(EntityModelLayers.WITHER_SKELETON)), 0.9f);
	}

	@Override
	protected void scale(FragmentedKingEntity e, MatrixStack m, float amount) { m.scale(1.8f, 1.8f, 1.8f); }

	@Override
	public Identifier getTexture(FragmentedKingEntity e) { return TEX; }
}
