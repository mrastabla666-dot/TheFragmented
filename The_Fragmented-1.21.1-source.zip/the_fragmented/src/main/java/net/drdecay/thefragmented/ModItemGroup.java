package net.drdecay.thefragmented;

import static net.drdecay.thefragmented.TheFragmented.id;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

public final class ModItemGroup {
	public static void init() {
		ItemGroup g = FabricItemGroup.builder()
				.icon(() -> new ItemStack(ModItems.TIN_INGOT))
				.displayName(Text.translatable("itemGroup.the_fragmented"))
				.entries((ctx, out) -> {
					for (ItemConvertible i : ModItems.ENTRIES) out.add(i);
					for (ItemConvertible i : ModBlocks.ENTRIES) out.add(i);
				}).build();
		Registry.register(Registries.ITEM_GROUP, id("main"), g);
	}
}
