package net.drdecay.thefragmented.item;

import net.drdecay.thefragmented.ModItems;
import net.minecraft.block.Block;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;

public enum TinMaterial implements ToolMaterial {
	INSTANCE;

	public int getDurability() { return 190; }
	public float getMiningSpeedMultiplier() { return 5.0f; }
	public float getAttackDamage() { return 1.5f; }
	public TagKey<Block> getInverseTag() { return BlockTags.INCORRECT_FOR_STONE_TOOL; }
	public int getEnchantability() { return 14; }
	public Ingredient getRepairIngredient() { return Ingredient.ofItems(ModItems.TIN_INGOT); }
}
