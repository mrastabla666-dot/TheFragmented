package net.drdecay.thefragmented.block;

import net.drdecay.thefragmented.entity.CementBagEntity;
import net.minecraft.block.Block;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Sneak + right-click on a block places it. Plain right-click throws it. */
public class BagOfCementItem extends BlockItem {
	public BagOfCementItem(Block block, Settings settings) { super(block, settings); }

	@Override
	public ActionResult useOnBlock(ItemUsageContext ctx) {
		PlayerEntity p = ctx.getPlayer();
		if (p != null && p.isSneaking()) return super.useOnBlock(ctx);
		return ActionResult.PASS;
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
		ItemStack stack = player.getStackInHand(hand);
		world.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ENTITY_SNOWBALL_THROW, SoundCategory.PLAYERS, 0.5f, 0.6f);
		if (!world.isClient) {
			CementBagEntity e = new CementBagEntity(world, player);
			e.setItem(stack);
			e.setVelocity(player, player.getPitch(), player.getYaw(), 0.0f, 1.2f, 1.0f);
			world.spawnEntity(e);
		}
		if (!player.getAbilities().creativeMode) stack.decrement(1);
		return TypedActionResult.success(stack, world.isClient());
	}
}
