package net.drdecay.thefragmented.entity;

import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.drdecay.thefragmented.ModEntities;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.datafixer.DataFixTypes;
import net.minecraft.entity.SpawnReason;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.structure.StructureStart;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.PersistentState;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureKeys;

/** Spawns The Fragmented King once per stronghold, the first time a player walks inside it. */
public final class StrongholdBoss {
	public static class State extends PersistentState {
		public final LongOpenHashSet spawned = new LongOpenHashSet();

		public static State load(NbtCompound nbt, RegistryWrapper.WrapperLookup l) {
			State s = new State();
			for (long v : nbt.getLongArray("spawned")) s.spawned.add(v);
			return s;
		}

		@Override
		public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup l) {
			nbt.putLongArray("spawned", spawned.toLongArray());
			return nbt;
		}
	}

	private static final PersistentState.Type<State> TYPE = new PersistentState.Type<>(State::new, State::load, DataFixTypes.LEVEL);

	public static void init() {
		ServerTickEvents.END_WORLD_TICK.register(world -> {
			if (world.getRegistryKey() != World.OVERWORLD || world.getTime() % 40 != 0) return;
			for (ServerPlayerEntity p : world.getPlayers()) {
				if (p.isSpectator()) continue;
				var structure = world.getRegistryManager().get(net.minecraft.registry.RegistryKeys.STRUCTURE).get(StructureKeys.STRONGHOLD);
				if (structure == null) continue;
				StructureStart start = world.getStructureAccessor().getStructureContaining(p.getBlockPos(), structure);
				if (!start.hasChildren()) continue;
				State st = world.getPersistentStateManager().getOrCreate(TYPE, "the_fragmented_boss");
				long key = start.getPos().toLong();
				if (st.spawned.add(key)) {
					if (spawn(world, p)) st.markDirty(); else st.spawned.remove(key);
				}
			}
		});
	}

	private static boolean spawn(ServerWorld world, ServerPlayerEntity player) {
		BlockPos base = player.getBlockPos();
		for (int i = 0; i < 40; i++) {
			BlockPos p = base.add(world.random.nextInt(17) - 8, world.random.nextInt(4) - 1, world.random.nextInt(17) - 8);
			FragmentedKingEntity k = ModEntities.FRAGMENTED_KING.create(world);
			if (k == null) return false;
			k.refreshPositionAndAngles(p.getX() + 0.5, p.getY(), p.getZ() + 0.5, world.random.nextFloat() * 360f, 0f);
			if (world.isSpaceEmpty(k) && world.getBlockState(p.down()).isSolidBlock(world, p.down())) {
				k.initialize(world, world.getLocalDifficulty(p), SpawnReason.EVENT, null);
				world.spawnEntity(k);
				player.sendMessage(Text.literal("The stronghold trembles... The Fragmented King awakens."), true);
				return true;
			}
		}
		return false;
	}
}
