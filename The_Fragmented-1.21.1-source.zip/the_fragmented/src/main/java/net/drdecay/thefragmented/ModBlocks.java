package net.drdecay.thefragmented;

import static net.drdecay.thefragmented.TheFragmented.id;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.drdecay.thefragmented.block.BagOfCementBlock;
import net.drdecay.thefragmented.block.BagOfCementItem;
import net.drdecay.thefragmented.block.MetalStringBlock;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.minecraft.block.*;
import net.minecraft.block.AbstractBlock.Settings;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.math.intprovider.UniformIntProvider;
import net.minecraft.world.gen.feature.ConfiguredFeature;

public final class ModBlocks {
	public static final List<ItemConvertible> ENTRIES = new ArrayList<>();

	public static final RegistryKey<ConfiguredFeature<?, ?>> ASHEN_TREE = RegistryKey.of(RegistryKeys.CONFIGURED_FEATURE, id("ashen_tree"));
	public static final RegistryKey<ConfiguredFeature<?, ?>> DUSK_TREE = RegistryKey.of(RegistryKeys.CONFIGURED_FEATURE, id("dusk_tree"));

	private static Settings copy(Block b) { return Settings.copy(b); }

	private static <T extends Block> T reg(String name, T block) {
		return reg(name, block, new BlockItem(block, new Item.Settings()));
	}

	private static <T extends Block> T reg(String name, T block, Item item) {
		Registry.register(Registries.BLOCK, id(name), block);
		Registry.register(Registries.ITEM, id(name), item);
		ENTRIES.add(item);
		return block;
	}

	private static void family(String prefix, Block base) {
		reg(prefix + "_stairs", new StairsBlock(base.getDefaultState(), copy(base)));
		reg(prefix + "_slab", new SlabBlock(copy(base)));
		reg(prefix + "_wall", new WallBlock(copy(base)));
	}

	public record Wood(Block log, Block strippedLog, Block wood, Block strippedWood, Block planks, Block stairs,
					   Block slab, Block fence, Block gate, Block leaves, Block sapling) {}

	private static Wood wood(String n, RegistryKey<ConfiguredFeature<?, ?>> tree) {
		Block log = reg(n + "_log", new PillarBlock(copy(Blocks.OAK_LOG)));
		Block slog = reg("stripped_" + n + "_log", new PillarBlock(copy(Blocks.STRIPPED_OAK_LOG)));
		Block wd = reg(n + "_wood", new PillarBlock(copy(Blocks.OAK_WOOD)));
		Block swd = reg("stripped_" + n + "_wood", new PillarBlock(copy(Blocks.STRIPPED_OAK_WOOD)));
		Block planks = reg(n + "_planks", new Block(copy(Blocks.OAK_PLANKS)));
		Block stairs = reg(n + "_stairs", new StairsBlock(planks.getDefaultState(), copy(planks)));
		Block slab = reg(n + "_slab", new SlabBlock(copy(Blocks.OAK_SLAB)));
		Block fence = reg(n + "_fence", new FenceBlock(copy(Blocks.OAK_FENCE)));
		Block gate = reg(n + "_fence_gate", new FenceGateBlock(WoodType.OAK, copy(Blocks.OAK_FENCE_GATE)));
		Block leaves = reg(n + "_leaves", new LeavesBlock(copy(Blocks.OAK_LEAVES)));
		Block sapling = reg(n + "_sapling", new SaplingBlock(
				new SaplingGenerator(n, Optional.empty(), Optional.of(tree), Optional.empty()), copy(Blocks.OAK_SAPLING)));

		StrippableBlockRegistry.register(log, slog);
		StrippableBlockRegistry.register(wd, swd);
		FlammableBlockRegistry f = FlammableBlockRegistry.getDefaultInstance();
		for (Block b : new Block[]{log, slog, wd, swd}) f.add(b, 5, 5);
		for (Block b : new Block[]{planks, stairs, slab, fence, gate}) f.add(b, 5, 20);
		f.add(leaves, 30, 60);
		for (Block b : new Block[]{log, slog, wd, swd, planks, stairs, fence, gate}) FuelRegistry.INSTANCE.add(b, 300);
		FuelRegistry.INSTANCE.add(slab, 150);
		FuelRegistry.INSTANCE.add(sapling, 100);
		return new Wood(log, slog, wd, swd, planks, stairs, slab, fence, gate, leaves, sapling);
	}

	// ---- ores & metal ----
	public static final Block TIN_ORE = reg("tin_ore", new ExperienceDroppingBlock(UniformIntProvider.create(0, 2), copy(Blocks.IRON_ORE)));
	public static final Block DEEPSLATE_TIN_ORE = reg("deepslate_tin_ore", new ExperienceDroppingBlock(UniformIntProvider.create(0, 2), copy(Blocks.DEEPSLATE_IRON_ORE)));
	public static final Block RAW_TIN_BLOCK = reg("raw_tin_block", new Block(copy(Blocks.RAW_IRON_BLOCK)));
	public static final Block TIN_BLOCK = reg("tin_block", new Block(copy(Blocks.IRON_BLOCK)));
	public static final Block CORRUGATED_METAL_WALL = reg("corrugated_metal_wall", new PaneBlock(copy(Blocks.IRON_BARS)));
	public static final Block BAMBOO_PILLAR = reg("bamboo_pillar", new PaneBlock(Settings.create().strength(1.0f).sounds(BlockSoundGroup.BAMBOO).nonOpaque()));
	public static final Block METAL_STRING = reg("metal_string", new MetalStringBlock(
			Settings.create().noCollision().breakInstantly().nonOpaque().sounds(BlockSoundGroup.CHAIN)
					.luminance(s -> s.get(MetalStringBlock.HOT) ? 7 : 0)));

	// ---- bricks ----
	public static final Block WHITE_BRICKS = reg("white_bricks", new Block(copy(Blocks.STONE_BRICKS)));
	public static final Block WEATHERED_BRICKS = reg("weathered_bricks", new Block(copy(Blocks.BRICKS)));
	static { family("white_brick", WHITE_BRICKS); family("weathered_brick", WEATHERED_BRICKS); }

	// ---- cement & concrete (SOLID_CEMENT must be created before CEMENT_BLOCK) ----
	public static final Block SOLID_CEMENT = reg("solid_cement", new Block(copy(Blocks.GRAY_CONCRETE)));
	static { family("solid_cement", SOLID_CEMENT); }
	public static final Block CEMENT_BLOCK = reg("cement_block", new ConcretePowderBlock(SOLID_CEMENT, copy(Blocks.GRAVEL)));
	public static final Block CONCRETE_BLOCK = reg("concrete_block", new Block(copy(Blocks.GRAY_CONCRETE)));
	public static final Block POWDERED_CONCRETE_BLOCK = reg("powdered_concrete_block", new ConcretePowderBlock(CONCRETE_BLOCK, copy(Blocks.GRAY_CONCRETE_POWDER)));

	public static final Block BAG_OF_CEMENT;
	static {
		BagOfCementBlock b = new BagOfCementBlock(Settings.create().strength(0.5f).sounds(BlockSoundGroup.WOOL).nonOpaque());
		BAG_OF_CEMENT = reg("bag_of_cement", b, new BagOfCementItem(b, new Item.Settings().maxCount(16)));
	}

	// ---- woods ----
	public static final Wood ASHEN = wood("ashen", ASHEN_TREE);
	public static final Wood DUSK = wood("dusk", DUSK_TREE);

	public static void init() {}
}
