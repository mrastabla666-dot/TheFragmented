package net.drdecay.thefragmented.entity;

import net.drdecay.thefragmented.ModEntities;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class FragmentedKingEntity extends HostileEntity implements net.minecraft.entity.mob.RangedAttackMob {
	private final ServerBossBar bossBar = new ServerBossBar(Text.translatable("entity.the_fragmented.fragmented_king"), BossBar.Color.PURPLE, BossBar.Style.NOTCHED_10);

	public FragmentedKingEntity(EntityType<? extends HostileEntity> type, World world) {
		super(type, world);
		experiencePoints = 100;
		setPersistent();
	}

	public static DefaultAttributeContainer.Builder createAttributes() {
		return HostileEntity.createHostileAttributes()
				.add(EntityAttributes.GENERIC_MAX_HEALTH, 300.0)
				.add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 14.0)
				.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.28)
				.add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0)
				.add(EntityAttributes.GENERIC_ARMOR, 8.0)
				.add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.8);
	}

	@Override
	protected void initGoals() {
		goalSelector.add(0, new SwimGoal(this));
		goalSelector.add(2, new MeleeAttackGoal(this, 1.0, false));
		goalSelector.add(5, new WanderAroundFarGoal(this, 0.8));
		goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 10.0f));
		goalSelector.add(7, new LookAroundGoal(this));
		targetSelector.add(1, new RevengeGoal(this));
		targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
	}

	@Override
	public boolean canImmediatelyDespawn(double distanceSquared) { return false; }

	@Override
	protected void mobTick() {
		super.mobTick();
		bossBar.setPercent(getHealth() / getMaxHealth());
		if (getTarget() != null && getWorld() instanceof ServerWorld sw) {
			if (age % 120 == 0) shockwave(sw);
			if (age % 400 == 0) summonHelpers(sw);
		}
	}

	private void shockwave(ServerWorld sw) {
		sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.HOSTILE, 1.0f, 0.5f);
		sw.spawnParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.2, getZ(), 12, 2.5, 0.1, 2.5, 0.0);
		for (PlayerEntity p : sw.getEntitiesByClass(PlayerEntity.class, new Box(getBlockPos()).expand(6), e -> true)) {
			p.damage(getDamageSources().mobAttack(this), 6.0f);
			p.addVelocity(0, 0.6, 0);
			p.velocityModified = true;
		}
	}

	private void summonHelpers(ServerWorld sw) {
		for (int i = 0; i < 2; i++) {
			ConstructorZombieEntity z = ModEntities.CONSTRUCTOR_ZOMBIE.create(sw);
			if (z == null) continue;
			z.refreshPositionAndAngles(getX() + random.nextInt(5) - 2, getY(), getZ() + random.nextInt(5) - 2, random.nextFloat() * 360f, 0);
			z.initialize(sw, sw.getLocalDifficulty(getBlockPos()), SpawnReason.MOB_SUMMONED, null);
			sw.spawnEntity(z);
		}
	}

	@Override
	public void onStartedTrackingBy(ServerPlayerEntity p) { super.onStartedTrackingBy(p); bossBar.addPlayer(p); }

	@Override
	public void onStoppedTrackingBy(ServerPlayerEntity p) { super.onStoppedTrackingBy(p); bossBar.removePlayer(p); }

	@Override
	public void readCustomDataFromNbt(NbtCompound nbt) { super.readCustomDataFromNbt(nbt); bossBar.setName(getDisplayName()); }

	@Override
	public void setCustomName(Text name) { super.setCustomName(name); bossBar.setName(getDisplayName()); }

	@Override
	public void shootAt(net.minecraft.entity.LivingEntity target, float pullProgress) {}
}
