package net.drdecay.thefragmented;

import static net.drdecay.thefragmented.TheFragmented.id;

import net.drdecay.thefragmented.entity.CementBagEntity;
import net.drdecay.thefragmented.entity.ConstructorZombieEntity;
import net.drdecay.thefragmented.entity.FragmentedKingEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.world.Heightmap;

public final class ModEntities {
	public static final EntityType<CementBagEntity> CEMENT_BAG = Registry.register(Registries.ENTITY_TYPE, id("cement_bag"),
			EntityType.Builder.<CementBagEntity>create(CementBagEntity::new, SpawnGroup.MISC)
					.dimensions(0.25f, 0.25f).maxTrackingRange(4).trackingTickInterval(10).build("cement_bag"));

	public static final EntityType<ConstructorZombieEntity> CONSTRUCTOR_ZOMBIE = Registry.register(Registries.ENTITY_TYPE, id("constructor_zombie"),
			EntityType.Builder.create(ConstructorZombieEntity::new, SpawnGroup.MONSTER)
					.dimensions(0.6f, 1.95f).maxTrackingRange(8).build("constructor_zombie"));

	public static final EntityType<FragmentedKingEntity> FRAGMENTED_KING = Registry.register(Registries.ENTITY_TYPE, id("fragmented_king"),
			EntityType.Builder.create(FragmentedKingEntity::new, SpawnGroup.MONSTER)
					.dimensions(1.2f, 3.6f).maxTrackingRange(10).build("fragmented_king"));

	public static void init() {
		FabricDefaultAttributeRegistry.register(CONSTRUCTOR_ZOMBIE, ZombieEntity.createZombieAttributes());
		FabricDefaultAttributeRegistry.register(FRAGMENTED_KING, FragmentedKingEntity.createAttributes());
		SpawnRestriction.register(CONSTRUCTOR_ZOMBIE, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
	}
}
