# The Fragmented (Fabric, Minecraft 1.21.1) — by Dr.Decay

## Build the .jar
Requires JDK 21. In this folder run:

    gradle build          (Gradle 8.8+; or copy gradle-wrapper.jar/gradlew from the official Fabric example mod and use ./gradlew build)

The mod jar appears in `build/libs/the_fragmented-1.0.0.jar`. Put it in `.minecraft/mods` with Fabric Loader 0.16+ and Fabric API 0.102.0+1.21.1.

## Implemented
- Tin: ore, deepslate ore (worldgen), raw tin, ingot, blocks, smelting/blasting, tin sword/pickaxe/axe/shovel/hoe + Tin Warhammer
- Bamboo Stick, Bamboo Pillar (pane, like iron bars), Corrugated Metal Wall (pane, made from tin + bamboo sticks)
- Metal String (1 iron ingot -> 4): lay on the ground; between two powered redstone sources (wire/torch/block, same axis) it glows, burns mobs, can ignite fires
- White Bricks, Weathered Bricks (+ stairs, slabs, walls, stonecutting)
- Cement Block (gravel-like, generates underground, hardens to Solid Cement in water, drops Powdered Cement), Solid Cement (+ stairs/slab/wall)
- Powdered Cement (1 block -> 9), Bag of Cement (paper + 8 powder): 3D model, slab-height 2x1 block (sneak+use to place), right-click to throw (5 dmg, light-grey smoke)
- Concrete Block + Powdered Concrete Block (hardens in water)
- Two wood families: Ashen and Dusk (log, stripped, wood, stripped wood, planks, stairs, slab, fence, fence gate, leaves, sapling, natural trees)
- The Fragmented King (300 HP boss, boss bar, shockwave, summons helpers) — spawns once per Stronghold when a player enters
- Constructor Zombie + "Unfinished Project" underground structure (spawns there)
- Enchantments: Rending (damage), Hotblade (ignite)
- Creative tab "The Fragmented", spawn eggs

## Simplifications / placeholders
- Textures are procedurally generated placeholders — replace in `assets/the_fragmented/textures`.
- The Bamboo Stick/Metal String "tie" mechanic for walls is represented by crafting recipes, not a special placement rule.
- Doors, trapdoors, signs, boats for new woods are not included.
